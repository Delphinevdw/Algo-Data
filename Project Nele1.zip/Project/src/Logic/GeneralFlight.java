package Logic;

public class GeneralFlight {

    
    
}
