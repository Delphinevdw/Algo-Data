// NOG DOEN
package Database;

public class DBTotalDuration {
    
}
